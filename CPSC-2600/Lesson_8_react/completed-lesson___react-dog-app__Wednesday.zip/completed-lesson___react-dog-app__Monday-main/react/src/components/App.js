// Make an application that allows users to browsse 
// different kinds of dogs, and see random images
// of those dogs.
import { useState } from 'react';
import TypeChooser from './TypeChooser.js';
import DogImage from './DogImage.js';
const App = props => {
    const [chosen, setChosen] = useState();
    // Somehow have to set the value of chosen in <App /> from inside <TypeChooser />
    return <>
        <h1>Dog Image Viewer: {chosen}</h1>
        <TypeChooser setChosen={setChosen} />
        <DogImage chosen={chosen} />
    </>;
}

export default App;