import { useEffect, useState } from 'react';

const DogImage = props => {

    const [imageSrc, setImageSrc] = useState();

    useEffect(function loadDogImageByType(){
        fetch(`https://dog.ceo/api/breed/${props.chosen}/images/random`)
        .then(response=>response.json())
        .then(objectResponse=>{
            // Do something with the image URL we received from the API.
            // CHALLENGE: display the image.
            setImageSrc(objectResponse.message)
        })
    }, 
    // When props.chosen changes the above function will be called and a new image will be loaded
    [props.chosen]);
    return <>
        <h2>The Image: {props.chosen}</h2>
        <img src={imageSrc} />
    </>
}

export default DogImage;