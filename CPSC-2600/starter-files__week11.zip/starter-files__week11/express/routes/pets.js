import express from 'express';
const petsRouter = express.Router();

import { getPets, postPet } from '../controllers/pets.js';

petsRouter.get('/', getPets);
petsRouter.post('/', postPet);

export default petsRouter;