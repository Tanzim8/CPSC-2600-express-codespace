import petsModel from '../models/pets.js';

const getPets = (req, res) => {
    // TODO
}

const postPet = (req, res) =>{
    // TODO
}

export { getPets, postPet };