import db from './db.js';

const getPets = num => {
    // TODO
}

const postPet = pet => {
    // TODO
}

export default {
    getPets,
    postPet
}