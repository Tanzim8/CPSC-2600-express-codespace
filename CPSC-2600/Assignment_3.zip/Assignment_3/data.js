const data = [
    {
        id: "hakushi-hasegawa",
        name: "Hakushi Hasegawa",
        topAlbums: [
            {
                id: "mahōgakkō",
                name: "Mahōgakkō",
                year: 2024
            },
            {
                id: "air-ni-ni",
                name: "Air Ni Ni",
                year: 2019
            }
        ]
    },
    {
        id: "soccer-mommy",
        name: "Soccer Mommy",
        topAlbums: [
            {
                id: "evergreen",
                name: "Evergreen",
                year: 2024
            }
        ]
    },
    {
        id: "palm",
        name: "Palm",
        topAlbums: [
            {
                id: "nicks-and-grazes",
                name: "Nicks and Grazes",
                year: 2022
            },
            {
                id: "rock-island",
                name: "Rock Island",
                year: 2018
            }
        ]
    },
    {
        id: "pink-floyd",
        name: "Pink Floyd",
        topAlbums: [
            {
                id: "the-dark-side-of-the-moon",
                name: "The Dark Side of The Moon",
                year: 1973
            },
            {
                id: "the-division-bell",
                name: "The Division Bell",
                year: 1994
            }
        ]
    }
];

export default data;